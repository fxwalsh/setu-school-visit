Extract all files together. Open main.py in Thonny with local Python 3 selected and press F5. For chart scripts, install pygal using Tools > Manage packages if needed. Open the resulting SVG in your web browser.
medals.csv: five historical rows from Charting champions; not current totals.
practice_medals.csv, pop.csv, gdp.csv: invented countries and fictional practice values. Population: millions. GDP: billions of example currency units.
Source: https://projects.raspberrypi.org/en/projects/charting-champions/0
Adapted examples: CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0/
