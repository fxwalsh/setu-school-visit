print('Welcome to Charting Champions!')
