from pygal import Bar
chart = Bar()
chart.title = 'Olympic medals - historical teaching sample'
us = ['United States', 2399]
ru = ['Russia', 1413]
gb = ['Great Britain', 1304]
fr = ['France', 780]
de = ['Germany', 671]
chart.add(us[0], us[1])
chart.add(ru[0], ru[1])
chart.add(gb[0], gb[1])
chart.add(fr[0], fr[1])
chart.add(de[0], de[1])
chart.render_to_file('lists-chart.svg')
