from pygal import Bar
chart = Bar()
chart.title = 'Fictional GDP (billions of example currency units)'
with open('gdp.csv', encoding='utf-8') as data_file:
    for line in data_file:
        if line.strip():
            pieces = line.strip().split(',')
            team = pieces[0]
            value = float(pieces[1])
            chart.add(team, value)
chart.render_to_file('gdp.svg')
