Run Python from this extracted folder. Install Pygal first.
medals.csv: five historical rows from Raspberry Pi Foundation Charting champions; not current totals.
practice_medals.csv, pop.csv, gdp.csv: invented countries and fictional practice values. Population: millions. GDP: billions of example currency units.
Source: https://projects.raspberrypi.org/en/projects/charting-champions/0
Adapted examples: CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0/
