from pygal import Bar
chart = Bar()
chart.title = 'Olympic medals - historical teaching sample'
with open('medals.csv', encoding='utf-8') as data_file:
    for line in data_file:
        if line.strip():
            pieces = line.strip().split(',')
            team = pieces[0]
            value = int(pieces[1])
            chart.add(team, value)
chart.render_to_file('main.svg')
